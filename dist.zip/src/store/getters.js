export const route = (state) => {
  return state.route
}
